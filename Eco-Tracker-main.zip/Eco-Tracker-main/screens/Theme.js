// Theme.js

export const theme = {
  backgroundColor: '#4CAF50',
  textColor: 'blue',
};
